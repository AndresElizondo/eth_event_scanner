-- Adminer 4.8.1 MySQL 5.7.36 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP DATABASE IF EXISTS `eth_tx`;
CREATE DATABASE `eth_tx` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `eth_tx`;

DROP TABLE IF EXISTS `uniswap_tx_swap`;
CREATE TABLE `uniswap_tx_swap` (
  `txhash` text COLLATE utf8_bin NOT NULL,
  `contractAddress` text COLLATE utf8_bin NOT NULL,
  `blockNumber` bigint(20) NOT NULL,
  `event` text COLLATE utf8_bin NOT NULL,
  `signature` text COLLATE utf8_bin NOT NULL,
  `sender` text COLLATE utf8_bin NOT NULL,
  `recipient` text COLLATE utf8_bin NOT NULL,
  `amount0` bigint(255) NOT NULL,
  `amount1` bigint(255) NOT NULL,
  `sqrtPriceX96` bigint(161) NOT NULL,
  `liquidity` bigint(128) NOT NULL,
  `tick` bigint(24) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

TRUNCATE `uniswap_tx_swap`;

DROP TABLE IF EXISTS `uniswap_tx_transfer`;
CREATE TABLE `uniswap_tx_transfer` (
  `txhash` text COLLATE utf8_bin NOT NULL,
  `contractAddress` text COLLATE utf8_bin NOT NULL,
  `blockNumber` bigint(20) NOT NULL,
  `event` text COLLATE utf8_bin NOT NULL,
  `signature` text COLLATE utf8_bin NOT NULL,
  `sender` text COLLATE utf8_bin NOT NULL,
  `recipient` text COLLATE utf8_bin NOT NULL,
  `total` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

TRUNCATE `uniswap_tx_transfer`;

-- 2021-11-29 04:44:16
